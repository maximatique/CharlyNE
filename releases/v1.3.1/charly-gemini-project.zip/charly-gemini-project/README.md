# CharlyNé — Gem Gemini

Package Projet CharlyNé — release de distribution v1.3.1.

La base de connaissance est identique dans les packages ChatGPT, Claude et Gemini. Seules les instructions d’adaptation à la plateforme diffèrent.

## Installation

1. Décompresser cette archive sur un ordinateur.
2. Dans Gemini, créer un nouveau Gem.
3. Copier le contenu de `INSTRUCTIONS.md` dans les instructions du Gem.
4. Ajouter les six fichiers du dossier `kb/` comme fichiers de connaissance lorsque cette option est disponible.
5. Démarrer une conversation avec le Gem et poser directement une question à CharlyNé.

## Utilisation

Handle principal : `@charly`.

Alias reconnus : `@charlyné`, `CoachNé`, `Lisnardassistant`, `assitantné`, `Charlyne`, `coachmilitant`.

## Contenu

- `INSTRUCTIONS.md` : socle Charly + adaptateur plateforme fusionnés ;
- `kb/charly_knowledge.jsonl` : connaissances actives ;
- `kb/charly_competences.jsonl` : catalogue de compétences ;
- `kb/charly_relations.jsonl` : relations ;
- `kb/charly_sources.jsonl` : sources ;
- `kb/charly_schema.json` : schéma runtime ;
- `kb/charly_kb_manifest.json` : manifeste de KB.

Auteur : Maximatique - Bureau NÉ 13 -  Aix en Provence
