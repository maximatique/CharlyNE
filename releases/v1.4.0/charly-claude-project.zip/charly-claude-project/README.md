# CharlyNé — Projet Claude

Package CharlyNé — release v1.4.0.

La KB Core est identique dans tous les packages. La couche KB Live est référencée par le manifeste et n'est consultée que lorsque la plateforme dispose d'un accès web/Drive compatible.

## Installation

1. Décompresser cette archive sur un ordinateur.
2. Créer un Projet Claude.
3. Copier `INSTRUCTIONS.md` dans les instructions.
4. Ajouter les six fichiers du dossier `kb/` comme fichiers de connaissance.
5. Commencer à utiliser CharlyNé.

## Utilisation

Handle principal : `@charly`.
Alias : `@charlyné`, `CoachNé`, `Lisnardassistant`, `assitantné`, `Charlyne`, `coachmilitant`.

Auteur : Maximatique - Bureau NÉ 13 -  Aix en Provence
